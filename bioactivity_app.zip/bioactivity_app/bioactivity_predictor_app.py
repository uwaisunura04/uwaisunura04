import streamlit as st
from rdkit import Chem
from rdkit.Chem import Descriptors
import pandas as pd
import joblib

# Load trained model and scaler
model = joblib.load("xgb_bioactivity_model.pkl")
scaler = joblib.load("scaler.pkl")

st.set_page_config(page_title="MTB Bioactivity Predictor", layout="wide")
st.title("🔬 MTB Bioactivity Predictor App")
st.markdown("Enter a **SMILES string** to predict if a compound is likely *bioactive* against **Mycobacterium tuberculosis virulent proteins**.")

smiles = st.text_input("🧪 Enter SMILES structure of compound:", "CC(=O)OC1=CC=CC=C1C(=O)O")

def compute_descriptors(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    desc = {
        'MolWt': Descriptors.MolWt(mol),
        'MolLogP': Descriptors.MolLogP(mol),
        'NumHDonors': Descriptors.NumHDonors(mol),
        'NumHAcceptors': Descriptors.NumHAcceptors(mol),
        'TPSA': Descriptors.TPSA(mol),
        'NumRotatableBonds': Descriptors.NumRotatableBonds(mol)
    }
    return pd.DataFrame([desc])

if st.button("🔍 Predict Bioactivity"):
    features = compute_descriptors(smiles)
    if features is not None:
        features_scaled = scaler.transform(features)
        prediction = model.predict(features_scaled)[0]
        confidence = model.predict_proba(features_scaled)[0][int(prediction)]
        label = "🟢 Active" if prediction == 1 else "🔴 Inactive"
        st.success(f"Prediction: **{label}** (Confidence: {confidence:.2f})")
        st.write("🧬 Molecular Descriptors:")
        st.dataframe(features.style.format(precision=2))
    else:
        st.error("❌ Invalid SMILES. Please enter a valid chemical structure.")